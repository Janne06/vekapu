/**
 * 
 */
package net.vekapu.util;

import junit.framework.JUnit4TestAdapter;
import junit.framework.TestCase;

import org.junit.Test;

/**
 * @author janne
 *
 */
public class DayHelperTest extends TestCase {

	/**
	 * @param arg0
	 */
	public DayHelperTest(String arg0) {
		super(arg0);
	}
		
	@Test public void test() throws Exception {
		DayHelper dayHelper = new DayHelper();
		boolean result = dayHelper.isMonday();
//		assertEquals("Onko maanantai", true, result);
		
		result = dayHelper.isTuesday();
		assertEquals("Onko tiistai", true, result);
		
	}
	
	public static junit.framework.Test suite() {
		return new JUnit4TestAdapter(DayHelperTest.class);
	}
/*
	private void test() {
		// Testataan luokan toimintaa
		try {
			logger.debug("Mikä päivä nyt on ? " + DayHelper.now());
			logger.debug("Onko lauantai ? " + this.isSaturday());
			logger.debug("Onko sunnuntai ? " + this.isSunday());
			logger.debug("Onko maanantai ? " + this.isMonday());
			logger.debug("Onko tiistai ? " + this.isTuesday());
			logger.debug("Onko keskiviikko ? " + this.isWednesday());

			String pvm = "24.4.2003";
			logger.debug("Onko tänään " + pvm + " ? " + this.isToday(pvm));
			logger.debug("Onko vanhentunut " + pvm + " ? "
					+ this.isExpired(pvm));

			String pvm2 = "24.4.2300";
			logger.debug("Onko vanhentunut " + pvm2 + " ? "
					+ this.isExpired(pvm2));

			logger.debug("Mikä vuosi ja viikko ? " + this.getYearWeek());
			logger.debug("Mikä vuosi ? " + this.getYear());
			logger.debug("Mikä oli viimeviikko ? " + this.getLastWeek());
		} catch (VekapuException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	*/
}
