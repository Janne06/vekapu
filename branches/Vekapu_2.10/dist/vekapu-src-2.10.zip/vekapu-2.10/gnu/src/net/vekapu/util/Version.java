//////////////////////////////////////////////////////////////////////////////
//
// Filename: Version.java
//
// Author:   Janne Ilonen
// Project:  Vekapu
//
// Purpose:  Project version number. (Only).
//
// (c) Copyright J.Ilonen, 2011 =>
//
// $Id: Version.java 359 2012-11-11 18:22:57Z janne.ilonen@vekapu.net $
//
//////////////////////////////////////////////////////////////////////////////
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details at gnu.org.
//
//////////////////////////////////////////////////////////////////////////////

package net.vekapu.util;

/**
 * Project version number.
 */

 public class Version {
	/*
	 Päivitä molemmat (versio & VERSION) numerot AINA SAMOIKSI. 
	 versio = 2.10
	 */
	private final static String VERSION = "2.10";
	

	/**
	 * Vekapu version number
	 * @return Version number
	 */
	public static String getVersionNumber() {
		return VERSION;
	}
	
}
