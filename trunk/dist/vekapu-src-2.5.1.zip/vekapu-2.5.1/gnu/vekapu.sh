#!/bin/bash
#
# $Id: vekapu.sh 9 2007-02-20 21:17:21Z janne.ilonen $
# Make this file executable:
# chmod 755 vekapu.sh

#cd /to/you/vekapu/vekapu-n.n.n/

# Full path to java if using kcron
#/where/is/java
java -cp ./lib/vekapu.jar:./lib/mail.jar:./lib/activation.jar:./lib/log4j.jar:. net.vekapu.Vekapu $1 $2 $3 $4 $5


