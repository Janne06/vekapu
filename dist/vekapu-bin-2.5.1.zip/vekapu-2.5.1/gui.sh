#!/bin/bash
#
# $Id: gui.sh 251 2009-07-06 17:25:24Z janne.ilonen $
# Make this file executable:
# chmod 755 vekapu.sh

#cd /to/you/vekapu/vekapu-n.n.n/

# Full path to java if using kcron
#/where/is/java
java -cp ./lib/vekapu.jar:./lib/mail.jar:./lib/activation.jar:./lib/log4j.jar:./lib/jmdi.jar:./lib/BrowserLauncher2-10.jar:.  net.vekapu.gui3.VekapuMdiGui $1 $2 $3 $4 $5


