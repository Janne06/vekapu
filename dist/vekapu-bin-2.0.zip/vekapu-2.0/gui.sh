#!/bin/bash
#
# $Id: gui.sh 9 2007-02-20 21:17:21Z janne.ilonen $
# Make this file executable:
# chmod 755 vekapu.sh

java -cp ./lib/vekapu.jar:./lib/mail.jar:./lib/activation.jar:./lib/log4j.jar:. net.vekapu.gui.VekapuGuiStarter $1 $2 $3 $4 $5
